// This file was @generated automatically

#define SAMPLE_OUTPUT { \
  0x50401000, 0xffffffff, 0x00000002, 0xffff6f2c, 0x000053b4, 0x00000000 \
}
